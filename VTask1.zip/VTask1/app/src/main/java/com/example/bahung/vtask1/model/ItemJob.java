package com.example.bahung.vtask1.model;

/**
 * Created by bahung on 24/03/2018.
 **/

public class ItemJob {
    private String title;

    public ItemJob(String title) {
        this.title = title;
    }
}
